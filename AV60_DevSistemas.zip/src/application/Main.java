package application;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Main extends JFrame {

    private JPanel currentScene;

    public Main() {
        setTitle("AV60_DesenvolvimentoDeSistemas");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Painel principal
        currentScene = createScene(Color.BLUE, "Cena 1");
        add(currentScene, BorderLayout.CENTER);

        // Painel com setas
        JPanel arrowsPanel = new JPanel(null);
        arrowsPanel.setPreferredSize(new Dimension(500, 100));

        JButton up = new JButton("↑");
        JButton down = new JButton("↓");
        JButton left = new JButton("←");
        JButton right = new JButton("→");

        up.setBounds(225, 0, 50, 40);
        down.setBounds(225, 50, 50, 40);
        left.setBounds(100, 25, 50, 40);
        right.setBounds(350, 25, 50, 40);

        arrowsPanel.add(up);
        arrowsPanel.add(down);
        arrowsPanel.add(left);
        arrowsPanel.add(right);

        add(arrowsPanel, BorderLayout.SOUTH);

        // Listeners para trocar de cena
        up.addActionListener(e -> switchScene(Color.BLUE, "Cena 1"));
        left.addActionListener(e -> switchScene(Color.GREEN, "Cena 2"));
        right.addActionListener(e -> switchScene(Color.RED, "Cena 3"));
        down.addActionListener(e -> switchScene(new Color(138, 43, 226), "Cena 4"));
    }

    private JPanel createScene(Color ballColor, String sceneName) {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                int diameter = 60;
                int x = getWidth() / 2 - diameter / 2;
                int y = getHeight() / 2 - diameter / 2;
                g.setColor(ballColor);
                g.fillOval(x, y, diameter, diameter);
                g.setColor(Color.BLACK);
                g.drawString(sceneName, 10, 20);
            }
        };
    }

    private void switchScene(Color color, String name) {
        remove(currentScene);
        currentScene = createScene(color, name);
        add(currentScene, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().setVisible(true));
    }
}
